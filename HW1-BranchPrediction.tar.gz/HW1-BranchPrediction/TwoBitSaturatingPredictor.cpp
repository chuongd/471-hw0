#include "TwoBitSaturatingPredictor.h"

TwoBitSaturatingPredictor::TwoBitSaturatingPredictor() : Predictor(){


}

BranchOutcome TwoBitSaturatingPredictor::predictBranch(ADDRINT addr){

  return Taken;

}

void TwoBitSaturatingPredictor::updatePredictor(ADDRINT addr, BranchOutcome o){


}

void TwoBitSaturatingPredictor::dumpStats(FILE * out) {
  Predictor::dumpStats(out);

  /* other stats */
}

extern "C" Predictor *Create(){

  return new TwoBitSaturatingPredictor();

}
