#include "Predictor.h"

class TwoBitSaturatingPredictor : public Predictor{

public:
  TwoBitSaturatingPredictor();  
  virtual BranchOutcome predictBranch(ADDRINT);
  virtual void updatePredictor(ADDRINT, BranchOutcome);
  virtual void dumpStats(FILE *);
};
