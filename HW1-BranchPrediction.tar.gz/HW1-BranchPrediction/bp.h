#ifndef _bp_h_
#define _bp_h_
enum BranchOutcome { NotTaken = 0, Taken = 1 };
#endif

